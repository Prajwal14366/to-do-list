import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import type { Todo, InsertTodo, UpdateTodo } from "@shared/schema";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  CheckCircle2, 
  Circle, 
  Edit2, 
  LogOut, 
  Plus, 
  Trash2, 
  ListTodo,
  X,
  Check,
  Download,
  Search,
  Filter,
  SortAsc,
} from "lucide-react";

const PRIORITIES = ["low", "medium", "high"] as const;
const CATEGORIES = ["general", "work", "personal", "shopping", "health"] as const;

function getPriorityColor(priority: string) {
  switch (priority) {
    case "high":
      return "text-red-600";
    case "medium":
      return "text-orange-600";
    case "low":
      return "text-green-600";
    default:
      return "text-gray-600";
  }
}

function getPriorityBgColor(priority: string) {
  switch (priority) {
    case "high":
      return "bg-red-100";
    case "medium":
      return "bg-orange-100";
    case "low":
      return "bg-green-100";
    default:
      return "bg-gray-100";
  }
}

export default function Home() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [priority, setPriority] = useState("medium");
  const [category, setCategory] = useState("general");
  const [dueDate, setDueDate] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState("");
  const [editDescription, setEditDescription] = useState("");
  const [editPriority, setEditPriority] = useState("medium");
  const [editCategory, setEditCategory] = useState("general");
  const [editDueDate, setEditDueDate] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [filterCategory, setFilterCategory] = useState<string | null>(null);
  const [filterPriority, setFilterPriority] = useState<string | null>(null);
  const [sortBy, setSortBy] = useState<"date" | "priority" | "status">("date");

  // Build query params dynamically
  const getQueryParams = () => {
    const params = new URLSearchParams();
    if (searchQuery) params.append("search", searchQuery);
    if (filterCategory) params.append("category", filterCategory);
    if (filterPriority) params.append("priority", filterPriority);
    if (sortBy && !searchQuery && !filterCategory && !filterPriority) {
      params.append("sortBy", sortBy);
    }
    return params.toString();
  };

  const queryString = getQueryParams();
  const { data: todos, isLoading } = useQuery<Todo[]>({
    queryKey: ["/api/todos", queryString],
    queryFn: async () => {
      const response = await apiRequest("GET", `/api/todos?${queryString}`, undefined);
      return await response.json();
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: InsertTodo) => {
      const response = await apiRequest("POST", "/api/todos", data);
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/todos"] });
      setTitle("");
      setDescription("");
      setPriority("medium");
      setCategory("general");
      setDueDate("");
      toast({
        title: "Task created",
        description: "Your task has been added successfully",
      });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to create task",
        variant: "destructive",
      });
    },
    onSettled: () => {
      // Reset mutation state to ensure form is always re-enabled
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: UpdateTodo }) => {
      const response = await apiRequest("PATCH", `/api/todos/${id}`, data);
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/todos"] });
      setEditingId(null);
      toast({
        title: "Task updated",
        description: "Your changes have been saved",
      });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update task",
        variant: "destructive",
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const response = await apiRequest("DELETE", `/api/todos/${id}`, undefined);
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/todos"] });
      toast({
        title: "Task deleted",
        description: "Task has been removed",
      });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to delete task",
        variant: "destructive",
      });
    },
  });

  const toggleMutation = useMutation({
    mutationFn: async ({ id, completed }: { id: string; completed: boolean }) => {
      const response = await apiRequest("PATCH", `/api/todos/${id}`, { completed });
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/todos"] });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update task",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;
    createMutation.mutate({ 
      title: title.trim(), 
      description: description.trim() || undefined,
      priority: priority as any,
      category,
      dueDate: dueDate ? new Date(dueDate).toISOString() : undefined,
    });
  };

  const handleEdit = (todo: Todo) => {
    setEditingId(todo.id);
    setEditTitle(todo.title);
    setEditDescription(todo.description || "");
    setEditPriority(todo.priority || "medium");
    setEditCategory(todo.category || "general");
    setEditDueDate(todo.dueDate ? new Date(todo.dueDate).toISOString().split('T')[0] : "");
  };

  const handleSaveEdit = (id: string) => {
    if (!editTitle.trim()) return;
    updateMutation.mutate({
      id,
      data: { 
        title: editTitle.trim(), 
        description: editDescription.trim() || undefined,
        priority: editPriority as any,
        category: editCategory,
        dueDate: editDueDate ? new Date(editDueDate).toISOString() : undefined,
      },
    });
  };

  const handleCancelEdit = () => {
    setEditingId(null);
    setEditTitle("");
    setEditDescription("");
  };

  const handleExport = (format: "csv" | "json") => {
    window.location.href = `/api/todos/export/${format}`;
    toast({
      title: "Export started",
      description: `Your todos are being downloaded as ${format.toUpperCase()}`,
    });
  };

  const activeTodos = todos?.filter((t) => !t.completed) || [];
  const completedTodos = todos?.filter((t) => t.completed) || [];
  const completedCount = completedTodos.length;
  const totalCount = todos?.length || 0;

  const getUserInitials = () => {
    if (user?.firstName && user?.lastName) {
      return `${user.firstName[0]}${user.lastName[0]}`.toUpperCase();
    }
    if (user?.email) {
      return user.email[0].toUpperCase();
    }
    return "U";
  };

  const getUserDisplayName = () => {
    if (user?.firstName && user?.lastName) {
      return `${user.firstName} ${user.lastName}`;
    }
    if (user?.email) {
      return user.email;
    }
    return "User";
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-background/80 backdrop-blur-sm border-b">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 bg-primary/10 rounded-md flex items-center justify-center">
                <ListTodo className="w-5 h-5 text-primary" />
              </div>
              <h1 className="text-xl font-semibold text-foreground">TaskFlow</h1>
            </div>
            
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2">
                <Avatar className="w-8 h-8">
                  <AvatarImage src={user?.profileImageUrl || undefined} className="object-cover" />
                  <AvatarFallback className="text-xs bg-primary/10 text-primary">
                    {getUserInitials()}
                  </AvatarFallback>
                </Avatar>
                <span className="text-sm font-medium text-foreground hidden sm:inline" data-testid="text-username">
                  {getUserDisplayName()}
                </span>
              </div>
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => window.location.href = '/api/logout'}
                data-testid="button-logout"
              >
                <LogOut className="w-4 h-4 mr-2" />
                <span className="hidden sm:inline">Logout</span>
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8 max-w-4xl">
        {/* Add Task Form */}
        <Card className="mb-6">
          <CardHeader className="pb-4">
            <h2 className="text-lg font-medium text-foreground">Add New Task</h2>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Input
                  placeholder="Task title"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="text-base"
                  disabled={createMutation.isPending}
                  data-testid="input-todo-title"
                />
              </div>
              <div>
                <Textarea
                  placeholder="Description (optional)"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="resize-none text-sm min-h-20"
                  disabled={createMutation.isPending}
                  data-testid="input-todo-description"
                />
              </div>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                <div>
                  <Select value={priority} onValueChange={setPriority}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {PRIORITIES.map((p) => (
                        <SelectItem key={p} value={p}>
                          {p.charAt(0).toUpperCase() + p.slice(1)}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Select value={category} onValueChange={setCategory}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {CATEGORIES.map((c) => (
                        <SelectItem key={c} value={c}>
                          {c.charAt(0).toUpperCase() + c.slice(1)}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="md:col-span-2">
                  <Input
                    type="date"
                    value={dueDate}
                    onChange={(e) => setDueDate(e.target.value)}
                    disabled={createMutation.isPending}
                  />
                </div>
              </div>
              <Button 
                type="submit" 
                className="w-full sm:w-auto"
                disabled={!title.trim() || createMutation.isPending}
                data-testid="button-add-task"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Task
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Controls */}
        <div className="mb-6 space-y-4">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search tasks..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
                data-testid="input-search"
              />
            </div>
            <div className="flex gap-2 flex-wrap">
              <Select value={filterCategory || ""} onValueChange={(v) => setFilterCategory(v || null)}>
                <SelectTrigger className="w-40">
                  <Filter className="w-4 h-4 mr-2" />
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All Categories</SelectItem>
                  {CATEGORIES.map((c) => (
                    <SelectItem key={c} value={c}>
                      {c.charAt(0).toUpperCase() + c.slice(1)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={filterPriority || ""} onValueChange={(v) => setFilterPriority(v || null)}>
                <SelectTrigger className="w-40">
                  <Filter className="w-4 h-4 mr-2" />
                  <SelectValue placeholder="Priority" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All Priorities</SelectItem>
                  {PRIORITIES.map((p) => (
                    <SelectItem key={p} value={p}>
                      {p.charAt(0).toUpperCase() + p.slice(1)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {!searchQuery && !filterCategory && !filterPriority && (
                <Select value={sortBy} onValueChange={(v) => setSortBy(v as any)}>
                  <SelectTrigger className="w-40">
                    <SortAsc className="w-4 h-4 mr-2" />
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="date">Sort by Date</SelectItem>
                    <SelectItem value="priority">Sort by Priority</SelectItem>
                    <SelectItem value="status">Sort by Status</SelectItem>
                  </SelectContent>
                </Select>
              )}
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => handleExport("csv")}
                data-testid="button-export-csv"
              >
                <Download className="w-4 h-4 mr-1" />
                CSV
              </Button>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => handleExport("json")}
                data-testid="button-export-json"
              >
                <Download className="w-4 h-4 mr-1" />
                JSON
              </Button>
            </div>
          </div>
        </div>

        {/* Stats */}
        {totalCount > 0 && (
          <div className="flex items-center gap-4 mb-4 text-sm text-muted-foreground">
            <span data-testid="text-total-count">{totalCount} total</span>
            {completedCount > 0 && (
              <span data-testid="text-completed-count">{completedCount} completed</span>
            )}
          </div>
        )}

        {/* Loading State */}
        {isLoading && (
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <Card key={i}>
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    <Skeleton className="w-5 h-5 rounded flex-shrink-0 mt-0.5" />
                    <div className="flex-1 space-y-2">
                      <Skeleton className="h-5 w-3/4" />
                      <Skeleton className="h-4 w-1/2" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Empty State */}
        {!isLoading && todos?.length === 0 && (
          <Card className="mt-8">
            <CardContent className="py-16">
              <div className="text-center">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-primary/10 rounded-full mb-4">
                  <CheckCircle2 className="w-8 h-8 text-primary" />
                </div>
                <h3 className="text-lg font-medium text-foreground mb-2" data-testid="text-empty-state">
                  No tasks found
                </h3>
                <p className="text-sm text-muted-foreground max-w-sm mx-auto">
                  {searchQuery || filterCategory || filterPriority ? "Try adjusting your filters" : "Add your first task to get started"}
                </p>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Active Todos */}
        {!isLoading && activeTodos.length > 0 && (
          <div className="space-y-3 mb-6">
            {activeTodos.map((todo) => (
              <Card key={todo.id} className="border-l-4 border-l-primary" data-testid={`card-todo-${todo.id}`}>
                <CardContent className="p-4">
                  {editingId === todo.id ? (
                    <div className="space-y-3">
                      <Input
                        value={editTitle}
                        onChange={(e) => setEditTitle(e.target.value)}
                        className="text-base font-medium"
                        data-testid={`input-edit-title-${todo.id}`}
                      />
                      <Textarea
                        value={editDescription}
                        onChange={(e) => setEditDescription(e.target.value)}
                        className="resize-none text-sm min-h-16"
                        placeholder="Description (optional)"
                        data-testid={`input-edit-description-${todo.id}`}
                      />
                      <div className="grid grid-cols-3 gap-2">
                        <Select value={editPriority} onValueChange={setEditPriority}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {PRIORITIES.map((p) => (
                              <SelectItem key={p} value={p}>
                                {p.charAt(0).toUpperCase() + p.slice(1)}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <Select value={editCategory} onValueChange={setEditCategory}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {CATEGORIES.map((c) => (
                              <SelectItem key={c} value={c}>
                                {c.charAt(0).toUpperCase() + c.slice(1)}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <Input
                          type="date"
                          value={editDueDate}
                          onChange={(e) => setEditDueDate(e.target.value)}
                        />
                      </div>
                      <div className="flex gap-2">
                        <Button 
                          size="sm" 
                          onClick={() => handleSaveEdit(todo.id)}
                          disabled={!editTitle.trim() || updateMutation.isPending}
                          data-testid={`button-save-edit-${todo.id}`}
                        >
                          <Check className="w-4 h-4 mr-1" />
                          Save
                        </Button>
                        <Button 
                          size="sm" 
                          variant="ghost" 
                          onClick={handleCancelEdit}
                          data-testid={`button-cancel-edit-${todo.id}`}
                        >
                          <X className="w-4 h-4 mr-1" />
                          Cancel
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-start gap-3">
                      <button
                        onClick={() => toggleMutation.mutate({ id: todo.id, completed: true })}
                        className="flex-shrink-0 mt-0.5 hover-elevate active-elevate-2 rounded-sm"
                        data-testid={`button-toggle-${todo.id}`}
                      >
                        <Circle className="w-5 h-5 text-primary" />
                      </button>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <h3 className="text-base font-medium text-foreground" data-testid={`text-todo-title-${todo.id}`}>
                            {todo.title}
                          </h3>
                          {todo.priority && (
                            <span className={`text-xs px-2 py-1 rounded ${getPriorityBgColor(todo.priority)} ${getPriorityColor(todo.priority)} font-semibold`}>
                              {todo.priority}
                            </span>
                          )}
                          {todo.category && (
                            <span className="text-xs px-2 py-1 rounded bg-blue-100 text-blue-700 font-semibold">
                              {todo.category}
                            </span>
                          )}
                          {todo.dueDate && (
                            <span className="text-xs text-muted-foreground">
                              {new Date(todo.dueDate).toLocaleDateString()}
                            </span>
                          )}
                        </div>
                        {todo.description && (
                          <p className="text-sm text-muted-foreground mt-1" data-testid={`text-todo-description-${todo.id}`}>
                            {todo.description}
                          </p>
                        )}
                      </div>
                      <div className="flex gap-1 flex-shrink-0">
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="h-8 w-8"
                          onClick={() => handleEdit(todo)}
                          data-testid={`button-edit-${todo.id}`}
                        >
                          <Edit2 className="w-4 h-4" />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="h-8 w-8 text-destructive hover:text-destructive"
                          onClick={() => deleteMutation.mutate(todo.id)}
                          data-testid={`button-delete-${todo.id}`}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Completed Todos */}
        {!isLoading && completedTodos.length > 0 && (
          <div className="space-y-3">
            <h3 className="text-sm font-medium text-muted-foreground">Completed</h3>
            {completedTodos.map((todo) => (
              <Card key={todo.id} className="opacity-60 border-l-4 border-l-muted" data-testid={`card-todo-${todo.id}`}>
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    <button
                      onClick={() => toggleMutation.mutate({ id: todo.id, completed: false })}
                      className="flex-shrink-0 mt-0.5 hover-elevate active-elevate-2 rounded-sm"
                      data-testid={`button-toggle-${todo.id}`}
                    >
                      <CheckCircle2 className="w-5 h-5 text-primary" />
                    </button>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h3 className="text-base font-medium text-foreground line-through" data-testid={`text-todo-title-${todo.id}`}>
                          {todo.title}
                        </h3>
                        {todo.priority && (
                          <span className={`text-xs px-2 py-1 rounded ${getPriorityBgColor(todo.priority)} ${getPriorityColor(todo.priority)} font-semibold opacity-50`}>
                            {todo.priority}
                          </span>
                        )}
                      </div>
                      {todo.description && (
                        <p className="text-sm text-muted-foreground line-through mt-1" data-testid={`text-todo-description-${todo.id}`}>
                          {todo.description}
                        </p>
                      )}
                    </div>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="h-8 w-8 text-destructive hover:text-destructive flex-shrink-0"
                      onClick={() => deleteMutation.mutate(todo.id)}
                      data-testid={`button-delete-${todo.id}`}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
