import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { CheckCircle2, ListTodo, User } from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50">
      <div className="container mx-auto px-4 py-16">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="text-center mb-12">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-primary/10 rounded-full mb-4">
              <ListTodo className="w-8 h-8 text-primary" />
            </div>
            <h1 className="text-4xl font-semibold text-foreground mb-3" data-testid="text-app-title">
              TaskFlow
            </h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              A simple, beautiful todo list app designed to help you stay organized and focused
            </p>
          </div>

          {/* Login Card */}
          <Card className="max-w-md mx-auto mb-12">
            <CardHeader className="text-center pb-4">
              <CardTitle className="text-2xl">Get Started</CardTitle>
              <CardDescription className="text-base">
                Sign in to access your personal todo list
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Button 
                className="w-full h-11" 
                size="lg"
                onClick={() => window.location.href = '/api/login'}
                data-testid="button-login"
              >
                <User className="w-4 h-4 mr-2" />
                Sign In
              </Button>
              <p className="text-xs text-center text-muted-foreground">
                Secure authentication powered by your account
              </p>
            </CardContent>
          </Card>

          {/* Features */}
          <div className="grid md:grid-cols-3 gap-6">
            <Card className="hover-elevate">
              <CardHeader className="pb-3">
                <div className="w-10 h-10 bg-primary/10 rounded-md flex items-center justify-center mb-2">
                  <CheckCircle2 className="w-5 h-5 text-primary" />
                </div>
                <CardTitle className="text-lg">Simple & Clean</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Focus on what matters with a distraction-free, light green themed interface
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="hover-elevate">
              <CardHeader className="pb-3">
                <div className="w-10 h-10 bg-primary/10 rounded-md flex items-center justify-center mb-2">
                  <ListTodo className="w-5 h-5 text-primary" />
                </div>
                <CardTitle className="text-lg">Track Your Tasks</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Create, edit, and complete tasks with ease. Your data is saved automatically
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="hover-elevate">
              <CardHeader className="pb-3">
                <div className="w-10 h-10 bg-primary/10 rounded-md flex items-center justify-center mb-2">
                  <User className="w-5 h-5 text-primary" />
                </div>
                <CardTitle className="text-lg">Personal & Secure</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Your todos are private and accessible only to you with secure authentication
                </CardDescription>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
