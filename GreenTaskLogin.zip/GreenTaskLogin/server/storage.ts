// Referenced from javascript_database and javascript_log_in_with_replit blueprints
import {
  users,
  todos,
  type User,
  type UpsertUser,
  type Todo,
  type InsertTodo,
  type UpdateTodo,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, ilike, or } from "drizzle-orm";

// Interface for storage operations
export interface IStorage {
  // User operations (Required for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Todo operations
  getTodosByUserId(userId: string): Promise<Todo[]>;
  getTodoById(id: string): Promise<Todo | undefined>;
  createTodo(userId: string, todo: InsertTodo): Promise<Todo>;
  updateTodo(id: string, userId: string, data: UpdateTodo): Promise<Todo | undefined>;
  deleteTodo(id: string, userId: string): Promise<boolean>;
  searchTodos(userId: string, query: string): Promise<Todo[]>;
  getTodosByCategory(userId: string, category: string): Promise<Todo[]>;
  getTodosByPriority(userId: string, priority: string): Promise<Todo[]>;
  getTodosSorted(userId: string, sortBy: "date" | "priority" | "status"): Promise<Todo[]>;
}

export class DatabaseStorage implements IStorage {
  // User operations (Required for Replit Auth)
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Todo operations
  async getTodosByUserId(userId: string): Promise<Todo[]> {
    return await db
      .select()
      .from(todos)
      .where(eq(todos.userId, userId))
      .orderBy(desc(todos.createdAt));
  }

  async getTodoById(id: string): Promise<Todo | undefined> {
    const [todo] = await db.select().from(todos).where(eq(todos.id, id));
    return todo;
  }

  async createTodo(userId: string, todo: InsertTodo): Promise<Todo> {
    const [newTodo] = await db
      .insert(todos)
      .values({
        ...todo,
        userId,
      })
      .returning();
    return newTodo;
  }

  async updateTodo(id: string, userId: string, data: UpdateTodo): Promise<Todo | undefined> {
    const [updatedTodo] = await db
      .update(todos)
      .set({
        ...data,
        updatedAt: new Date(),
      })
      .where(and(eq(todos.id, id), eq(todos.userId, userId)))
      .returning();
    
    return updatedTodo;
  }

  async deleteTodo(id: string, userId: string): Promise<boolean> {
    // First check if the todo exists and belongs to the user
    const todo = await this.getTodoById(id);
    if (!todo || todo.userId !== userId) {
      return false;
    }

    await db.delete(todos).where(eq(todos.id, id));
    return true;
  }

  async searchTodos(userId: string, query: string): Promise<Todo[]> {
    return await db
      .select()
      .from(todos)
      .where(
        and(
          eq(todos.userId, userId),
          or(
            ilike(todos.title, `%${query}%`),
            ilike(todos.description, `%${query}%`)
          )
        )
      )
      .orderBy(desc(todos.createdAt));
  }

  async getTodosByCategory(userId: string, category: string): Promise<Todo[]> {
    return await db
      .select()
      .from(todos)
      .where(and(eq(todos.userId, userId), eq(todos.category, category)))
      .orderBy(desc(todos.createdAt));
  }

  async getTodosByPriority(userId: string, priority: string): Promise<Todo[]> {
    return await db
      .select()
      .from(todos)
      .where(and(eq(todos.userId, userId), eq(todos.priority, priority as any)))
      .orderBy(desc(todos.createdAt));
  }

  async getTodosSorted(userId: string, sortBy: "date" | "priority" | "status"): Promise<Todo[]> {
    let orderByClause;
    
    switch (sortBy) {
      case "date":
        orderByClause = [todos.dueDate, desc(todos.createdAt)];
        break;
      case "priority":
        orderByClause = [todos.priority, desc(todos.createdAt)];
        break;
      case "status":
        orderByClause = [todos.completed, desc(todos.createdAt)];
        break;
      default:
        orderByClause = desc(todos.createdAt);
    }

    return await db
      .select()
      .from(todos)
      .where(eq(todos.userId, userId))
      .orderBy(...(Array.isArray(orderByClause) ? orderByClause : [orderByClause]));
  }
}

export const storage = new DatabaseStorage();
