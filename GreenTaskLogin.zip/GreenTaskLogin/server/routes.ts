// Referenced from javascript_log_in_with_replit blueprint
import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertTodoSchema, updateTodoSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Todo routes
  
  // Get all todos for the current user (with optional filtering/sorting)
  app.get("/api/todos", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { search, category, priority, sortBy } = req.query;
      
      let todos;
      if (search) {
        todos = await storage.searchTodos(userId, search as string);
      } else if (category) {
        todos = await storage.getTodosByCategory(userId, category as string);
      } else if (priority) {
        todos = await storage.getTodosByPriority(userId, priority as string);
      } else if (sortBy) {
        todos = await storage.getTodosSorted(userId, sortBy as any);
      } else {
        todos = await storage.getTodosByUserId(userId);
      }
      
      res.json(todos);
    } catch (error) {
      console.error("Error fetching todos:", error);
      res.status(500).json({ message: "Failed to fetch todos" });
    }
  });

  // Create a new todo
  app.post("/api/todos", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const validatedData = insertTodoSchema.parse(req.body);
      const todo = await storage.createTodo(userId, validatedData);
      res.status(201).json(todo);
    } catch (error) {
      console.error("Error creating todo:", error);
      res.status(400).json({ message: "Failed to create todo" });
    }
  });

  // Update a todo
  app.patch("/api/todos/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { id } = req.params;
      const validatedData = updateTodoSchema.parse(req.body);
      const todo = await storage.updateTodo(id, userId, validatedData);
      
      if (!todo) {
        return res.status(404).json({ message: "Todo not found or unauthorized" });
      }
      
      res.json(todo);
    } catch (error) {
      console.error("Error updating todo:", error);
      res.status(400).json({ message: "Failed to update todo" });
    }
  });

  // Delete a todo
  app.delete("/api/todos/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { id } = req.params;
      const success = await storage.deleteTodo(id, userId);
      
      if (!success) {
        return res.status(404).json({ message: "Todo not found or unauthorized" });
      }
      
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting todo:", error);
      res.status(500).json({ message: "Failed to delete todo" });
    }
  });

  // Export todos as CSV
  app.get("/api/todos/export/csv", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const allTodos = await storage.getTodosByUserId(userId);
      
      const headers = ["Title", "Description", "Priority", "Category", "Due Date", "Status", "Created"];
      const rows = allTodos.map(todo => [
        `"${(todo.title || "").replace(/"/g, '""')}"`,
        `"${(todo.description || "").replace(/"/g, '""')}"`,
        todo.priority || "medium",
        todo.category || "general",
        todo.dueDate ? new Date(todo.dueDate).toISOString().split('T')[0] : "",
        todo.completed ? "Completed" : "Active",
        new Date(todo.createdAt).toISOString().split('T')[0],
      ]);
      
      const csv = [headers.join(","), ...rows.map(r => r.join(","))].join("\n");
      
      res.setHeader("Content-Type", "text/csv");
      res.setHeader("Content-Disposition", "attachment; filename=todos.csv");
      res.send(csv);
    } catch (error) {
      console.error("Error exporting todos:", error);
      res.status(500).json({ message: "Failed to export todos" });
    }
  });

  // Export todos as JSON
  app.get("/api/todos/export/json", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const allTodos = await storage.getTodosByUserId(userId);
      
      res.setHeader("Content-Type", "application/json");
      res.setHeader("Content-Disposition", "attachment; filename=todos.json");
      res.json({ todos: allTodos, exportedAt: new Date().toISOString() });
    } catch (error) {
      console.error("Error exporting todos:", error);
      res.status(500).json({ message: "Failed to export todos" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
